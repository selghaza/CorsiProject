# CorsiProject
Group 8, Corsi-Block Tapping (NIH)
Sherief El-Ghazawi - selghazawi@gmail.com
Muhammad Abdel Motagaly - muhammad.motagaly@gmail.com
Randy Verduguez - reoverduguez@gmail.com
